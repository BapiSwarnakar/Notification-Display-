<!DOCTYPE html>
<html>
<head>
	<title>Push Notification</title>
	<script src="Ajax & jquery/jquery-3.5.1.js"></script>
	<script src="push.min.js"></script>
	<script src="serviceWorker.min.js"></script>
</head>
<body>
<a href="javascript:void(0)" onclick="start();">Start</a>
</body>
<script type="text/javascript">
	function start() {
		Push.create("Hello world!", {
	    body: "How's it hangin'?",
	    icon: '1.jpg',
	    timeout: 4000,
	    onClick: function () {
	    	window.location='https://google.com';
	        //window.focus();
	        this.close();
	    }
});
	}
</script>
</html>